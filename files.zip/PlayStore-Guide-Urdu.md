# 🏁 Turbo Race — Play Store Upload Guide

## Failo ki List
- `turbo-race-game.html` — Main game file
- `manifest.json` — PWA settings
- `PlayStore-Guide-Urdu.md` — Yeh guide

---

## STEP 1: Game ko Free Hosting pe Upload karo

### GitHub Pages (Bilkul Free)
1. **github.com** pe account banao
2. New Repository banao → naam: `turbo-race`
3. Dono files (`turbo-race-game.html` + `manifest.json`) upload karo
4. Settings → Pages → Branch: main → Save
5. Aapka URL milega: `https://AAPKA-NAAM.github.io/turbo-race/turbo-race-game.html`

---

## STEP 2: App Icon Banao

Kisi bhi phone ya PC mein:
- **canva.com** pe jao → Custom Size: 512x512
- Racing car ya checkered flag design banao
- Download: PNG format mein
- `icon-192.png` (192x192) aur `icon-512.png` (512x512) save karo
- GitHub pe upload karo

---

## STEP 3: APK Banao (TWA Method)

### PC pe:
1. **Node.js** install karo: nodejs.org
2. CMD/Terminal mein:
```
npm install -g @bubblewrap/cli
bubblewrap init --manifest https://AAPKA-NAAM.github.io/turbo-race/manifest.json
bubblewrap build
```
3. `app-release-signed.apk` file mil jaegi

### Online (PC nahi hai toh):
- **pwabuilder.com** website pe jao
- Apna GitHub Pages URL paste karo
- "Build My PWA" dabao
- Android → Download package

---

## STEP 4: Google Play Console

1. **play.google.com/console** → Account banao
2. **$25 ek baar ki fees** pay karo (debit/credit card)
3. "Create app" → App name: Turbo Race
4. APK file upload karo
5. Screenshots add karo (phone ka screenshot lo)
6. Description likho
7. Content rating fill karo (Everyone)
8. **Submit for review** → 3-7 din mein approve hoga!

---

## Privacy Policy (Zaruri hai)

Is text ko kisi bhi free site pe host karo (github pe bhi):

```
Privacy Policy for Turbo Race

This app does not collect any personal data.
High scores are saved locally on your device only.
No internet connection required to play.

Contact: aapki@email.com
```

---

## Extra Features jo Game mein Hain:
- ❤️ 3 Lives system
- ⚡ Boost button
- 💰 Coins collect karo (+50 score)
- 🏆 High score save hota hai (localStorage)
- 📱 Touch controls mobile ke liye
- ⏸ Pause/Resume button
- Speed automatic barhti hai

---

**Koi problem ho toh poochho! 🚀**
